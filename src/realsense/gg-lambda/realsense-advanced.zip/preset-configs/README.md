# AWS Greengrass Edge Development Kit

#### Intel RealSense d435 / 415 Preset configs

These preset confgs are adapted from: [Intel Git Configs](https://github.com/IntelRealSense/librealsense/wiki/D400-Series-Visual-Presets)


